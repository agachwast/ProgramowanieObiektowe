﻿namespace EDoor
{
   class Program
    {
        static void test1()
        {
            ArtDecoDoor d1 = new("Agatameble", 400);
            d1.AssignColor(EnumColor.black);
            d1.AssignColor(EnumColor.white);
            SpecialDoor d2 = new("BlackRedWhite", 500, EnumExtraFeature.alarm);
            DoorShop shop = new("Sklep");
            shop.RegisterDoor(d2);
            shop.RegisterDoor(d1);
            Console.WriteLine(shop);

        }
        static void Main()
        {
            test1();
        }
    }
}