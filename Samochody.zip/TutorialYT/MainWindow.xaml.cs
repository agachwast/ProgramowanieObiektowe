﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TutorialYT
{
    /// <summary>
    /// Logika interakcji dla klasy MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        ListaSerwisow serwisy = new ListaSerwisow(); 
        public MainWindow()
        {
            InitializeComponent();
            serwisy.DodajSerwis(new Samochod("9999", "opel", "ultra", new Wlasciciel("jan", "kowalski")), "czyszczenie");
            serwisy.DodajSerwis(new Samochod("1111", "bmw", "x5", new Wlasciciel("agnieszka", "groszek")), "naprawa");
        }

        private void ButtonSzukaj_Click(object sender, RoutedEventArgs e)
        {
            Wlasciciel wlasciciel = new Wlasciciel(TextBoxImie.Text, TextBoxNazwisko.Text);
            var s = serwisy.Wyszukaj(wlasciciel);
            
            if(s.Count() != 0 && s != null)
            {
                ListBoxSerwisy.ItemsSource = null;
                ListBoxSerwisy.ItemsSource = s;
            }
            else if(s.Count() == 0)
            {
                ListBoxSerwisy.ItemsSource = null;
                ListBoxSerwisy.ItemsSource = new List<string>() { "Nie znaleziono"};
            }

        }
    }
}
