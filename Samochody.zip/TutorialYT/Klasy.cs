﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TutorialYT
{
    public struct Wlasciciel
    {
        public string imie;
        public string nazwisko;

        public Wlasciciel(string imie, string nazwisko)
        {
            this.imie = imie;
            this.nazwisko = nazwisko;
        }
    }
    public class Samochod
    {
        public string nrRejestracyjny;
        public string marka;
        public string model;
        public Wlasciciel wlasciciel;

        public Samochod() { }

        public Samochod(string nrRejestracyjny, string marka, string model, Wlasciciel wlasciciel)
        {
            this.nrRejestracyjny = nrRejestracyjny;
            this.marka = marka;
            this.model = model;
            this.wlasciciel = wlasciciel;
        }

    }

    public class Serwis
    {
        public DateTime data;
        public Samochod auto;
        public string usluga;

        public Serwis()
        {
                
        }
        public Serwis(Samochod auto, string usluga)
        {
            this.auto = auto;
            this.usluga = usluga;
            this.data = DateTime.Now;
        }

        public Serwis(DateTime data, Samochod auto, string usluga)
        {
            this.data = data;
            this.auto = auto;
            this.usluga = usluga;
        }

        public override string ToString()
        {
            return $"{this.data.ToString("yyyy-MMMM-dd")}, {this.auto.nrRejestracyjny} {this.auto.nrRejestracyjny} " +
                $"{this.auto.marka} {this.auto.model} {this.usluga}";
        }
    }

    public class ListaSerwisow
    {
        public LinkedList<Serwis> serwisy;

        public ListaSerwisow()
        {
            serwisy = new LinkedList<Serwis>();
        }

        public void DodajSerwis(Samochod s, string usluga)
        {
            Serwis serw = new Serwis(s, usluga);
            serwisy.AddLast(serw);
        }
        public void DodajSerwis(Samochod s, string usluga, DateTime d)
        {
            Serwis serw = new Serwis(d, s, usluga);
            serwisy.AddLast(serw);
        }

        public List<Serwis> Wyszukaj(Wlasciciel w)
        {   
            return serwisy.Where(s => s.auto.wlasciciel.Equals(w)).ToList();

        }


    }
    

}
