﻿namespace EMydlo
{
    class Program
    {

        static void test1()
        {
            Soap s1 = new Soap("yellow", 12);
            FragranceSoap s2 = new FragranceSoap("blue", 12, "wood");
            //Console.WriteLine(s1);
            SoapStore store = new SoapStore("Store");
            store.AddSoap(s1);
            store.AddSoap(s2);
            Console.WriteLine(store);
        }

        static void test2()
        {
            FragranceSoap s2 = new FragranceSoap("blue", 12, "wood");
            Console.WriteLine(s2);
        }
        static void Main()
        {
            test1();
           // test2();
        }
    }
}