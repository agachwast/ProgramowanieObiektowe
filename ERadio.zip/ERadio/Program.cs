﻿namespace ERadio
{
    class Program
    {
        static void Main()
        {
            DateTime data = new DateTime(2025, 03, 11, 08, 15, 00);
            ClockRadio r1 = new ClockRadio(EnumRadioBrand.jbl, true);
            r1.SetAlarms("wstawaj", data);
            r1.SetAlarms("wstawaj elo", data);
            //Console.WriteLine(r1);
            RadioStore store = new("Sklep");
            store.RegisterRadio(r1);
            Console.WriteLine(store.FindClockRadio());
        }
    }
}